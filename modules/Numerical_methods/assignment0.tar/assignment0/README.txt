GENERAL EXECUTION INSTRUCTIONS:

due to the structure of the scripts, any specific PROGRAM.py has to be executed like this:

$ python PROGRAM.py


--------------------------------------------------------------

GENERAL DIRECTORIES STRUCTURE (output from command: tree -a .):

*********************
.
├── part.a
│   └── matrix_turn.py
└── README.txt

1 directory, 2 files
*********************
