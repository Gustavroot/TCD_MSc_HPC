#!/bin/bash

python cubic_spline.py
./call_gnuplot.sh
