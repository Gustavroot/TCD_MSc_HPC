#!/bin/bash

echo "Plotting data for cubic splines:"
gnuplot data_params/*
echo "... done."

echo "Plotting errors data:"
#TODO: add here some code for plotting errors data
echo "... done."
