#include <iostream>
#include <string>

using namespace std;

class MyClass {

public:

  void set_name( string name_) {
    name = name_;
  };

  void print(){
    std::cout << name << std::endl;
  };


  virtual void virt(){
    std::cout << "virtual function" << std::endl;
  };

  virtual void pure_virt()=0;
  
protected:
  int n = 42;

private:
  string name;
  
};




class MyDerived : public MyClass {

public:

  void print_n(){
    std::cout << "n = " << n << std::endl;
  }

  void print_x(){
    std::cout << "x = " << x << std::endl;
  }

  void virt(){
    std::cout << "overridden virtual function" << std::endl;
  }

  void pure_virt(){
    std::cout << "overridden pure virtual function" << std::endl;
  }

private:
  double x = 3.14159;
  
};










int main(){

  string obj_name = "my_class";
  
  //MyClass new_Object; //not allowed - contains virtual
  //new_Object.set_name(obj_name);
  //new_Object.print();
  
  MyDerived derived_Object;
  derived_Object.set_name("my_derived");
  derived_Object.print();
  derived_Object.print_n();
  derived_Object.virt();
  derived_Object.pure_virt();
  
}
