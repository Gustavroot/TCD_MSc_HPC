class base_A {
public:
  virtual void method_A()=0;
};

class derived_A : public base_A { 
public:
  void method_A() override {
    //stuff
  };
};

class derived_B : public base_A { 
public:
  void method_A() final {
    //stuff
  };
};

class derived_C : public derived_B { //B will not compile
public:
  void method_A() {
    //stuff
  };
};

int main(){

  derived_B obj;
  
  return 0;
}
