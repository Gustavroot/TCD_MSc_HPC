#include<iostream>

using namespace std;

class myClass {

public:
  static void do_a_thing(){
    cout << "a thing" << endl;
  }
};


int main(){

  //many ways of accessing things...
  myClass obj;
  obj.do_a_thing();
  

  //using pointer-like notation
  myClass *objP = new myClass;
  (*objP).do_a_thing();
  objP->do_a_thing();

  cout << endl << endl;
  
  //using pointer directly to function
  void (*ptr) () = &myClass::do_a_thing;
  (*ptr)();

}
