#include "functions.h"

//abstract classes
class genericIntegrator {

 public:
  virtual double integrate( integrandF &f )=0;

};


//instantiable derived classes
class intRect : public genericIntegrator {
 public:
  virtual double integrate( integrandF &f );

};

class intTrapz : public genericIntegrator {
 public:
  virtual double integrate( integrandF &f );

};
