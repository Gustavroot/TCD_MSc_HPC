#include<iostream>
#include<cmath>

#include "integrator.h"

using namespace std;



int main(){


  
  cout << "test functions" << endl;
  fn_exp my_fn_exp; fn_sin my_fn_sin; fn_poly my_fn_poly;

  cout << "e^1 = "       << my_fn_exp.f(1.0) << endl;
  cout << "sin(pi/2) = " << my_fn_sin.f(3.1415926535898/2.0) << endl;
  cout << "poly(1) = "   << my_fn_poly.f(1.0) << endl;

  cout << endl;
  
  {
    cout << "test integrator" << endl;
    intRect my_integrator; //rectangle version
  
    double answer = my_integrator.integrate( my_fn_exp );

    cout << "answer = " << answer << endl;
  }


  //runtime switching
  cout << "Rectangle rule, trapezium rule? (t/r)" << endl;

  char inp;
  cin >> inp;
  
  genericIntegrator *gInt;
  integrandF *intF;
  
  if (inp=='r'){
    gInt = new intRect;  //rectangle version
  } else if (inp=='t'){
    gInt = new intTrapz; //trapz version
  } else {
    cerr << "oops" << endl; exit(1);
  }

  cout << "Exp, Sin, Poly? (e/s/p)" << endl;

  char inp2;
  cin >> inp2;

  switch(inp2){
    case 'e':
      intF = new fn_exp; break;

    case 's':
      intF = new fn_sin; break;
    
    case 'p':
      intF = new fn_poly; break;
      
    default:
      cerr << "oops" << endl; exit(1);
  }
  
  cout << "factory ans = " << (*gInt).integrate( *intF ) << endl;
  
}

