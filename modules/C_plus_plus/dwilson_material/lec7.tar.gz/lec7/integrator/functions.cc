#include "functions.h"
#include <cmath>

//abstract integrand class integrandF -- nothing needed here

//definitions for the instantiable derived classes
double fn_exp::f(double x) { return exp(x); }

double fn_sin::f(double x) { return sin(x); }

double fn_poly::f(double x) { return x + 2*pow(x,2) + 6*pow(x,3); }


