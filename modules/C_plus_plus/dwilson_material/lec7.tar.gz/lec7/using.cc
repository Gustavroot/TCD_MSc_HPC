#include <iostream>
#include <string>

using namespace std;


class A {
public:
  void print(){
    cout << "method function in A" << endl;
  }

protected:
  void print_protected(){
    cout << "protected method function in A" << endl;
  }

private:
  void print_private(){
    cout << "protected method function in A" << endl;
  } 
};

class B : public A {
public:
  using A::print;            //fine
  using A::print_protected;  //make it usable externally
  //using A::print_private;  //not allowed
};


  
int main () {

  B objB;
  objB.print();
  objB.print_protected();
  
  return 0;
}
