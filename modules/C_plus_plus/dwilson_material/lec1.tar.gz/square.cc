#include<iostream>
#include<math.h>
#include<complex.h>

using namespace std;

int do_square( const int &a){
  int sq = a*a;
  return sq;
}

/*double do_square( const double &x){
  return x*x;
  }*/

complex<double> do_square( complex<double> z ){
  cout << "using complex version" << endl;
  return z*z;
}

double do_square( const double &x){
  complex<double> zz = do_square( complex<double>(x,0.0) );
  return zz.real();
}


int main(){
  
  int inp = 6;
  int outp = do_square( inp );

  cout << "in = " << inp << " outp = " << outp << endl;
  
  double dubin = 1.41421;
  double dubout = do_square( dubin ); 
  
  cout << "in = " << dubin << " outp = " << dubout << endl;
  
  return 0;
}
