#include<iostream>

using namespace std;

int main() {

  const int i = 10; //okay

  //i = 11; //fails

  //const int j; //fails

  int k = i; //okay, type conversion from const

  k++; //okay

  const int n = k; //okay

  return 0;
}
