#include <iostream> //input/output
#include <math.h> //math functions
#include <complex.h> //for complex numbers

using namespace std;

int main(){

  //integers
  int i = 17;
  short j {10}; //c++11
  long k {1234567890000}; //c++11

  //floating point
  float r = 3.14159;
  double dub = 3.141592653589;

  //complex numbers x + i y
  complex<double> z = complex<double>(0.1,5.0);

  //character/strings
  string mystring = "some letters";

  bool true_or_false = true;
  
  //arrays
  int arr[3];
  arr[0]=12;
  arr[1]=2;
  arr[2]=99;
 
  double nums[2];
  nums[0]=3.14159;
  nums[1]=sqrt(2);

  cout << "i= " << i << endl
       << "j= " << j << endl
       << "k= " << k << endl
       << "r= " << r << endl
       << "dub= " << dub << endl
       << "z = " << z << endl
       << "a_2= " << arr[2] << endl
       << "n_1= " << nums[1] << endl;

  cout <<  mystring << endl;
		       
  return 0;
}


