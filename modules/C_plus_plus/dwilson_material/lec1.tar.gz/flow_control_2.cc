#include <iostream>

using namespace std;

int main () {
  
  int j=0;
  while(j<10){

    cout << j << " ";

    switch(j){
    case 1:
      cout << "a" << endl;
      break;
    
    case 2:
      cout << "b" << endl;
      break;

    case 5:
      cout << "e" << endl;
      break;
      
    default:
      cout << j << endl;
      break;
    }
    
    j++; //j=j+1
  }
  return 0;
}
