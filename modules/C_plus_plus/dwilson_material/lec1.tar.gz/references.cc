#include <iostream>

using namespace std;



int main () {

  double a = 0.1;

  cout << a << endl;
  cout << &a << endl;
  cout << *(&a) << endl;

  cout << endl << endl;

  double *b = &a;
  cout << b << endl;
  cout << &b << endl;
  cout << *(&b) << endl;

  cout << endl << endl;

  double &c = a;
  cout << c << endl;
  cout << &c << endl;
  cout << *(&c) << endl;

  cout << endl << endl;
  
  double *x = new double;
  *x = 3.14;
  
  cout <<    x << endl;
  cout <<   &x << endl;
  cout <<  (*x) << endl;
  cout <<  (&x) << endl;
  cout << *(&x) << endl;
  cout << &(*x) << endl;

  delete x;
  
  return 0;
}

