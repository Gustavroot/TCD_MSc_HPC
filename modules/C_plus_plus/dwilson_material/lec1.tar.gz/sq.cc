#include<iostream>

using namespace std;


int do_square( int a ){
  int sq = a*a;
  return sq;
}


int main (){

  cout << do_square( 4 ) << endl;
  
  return 0;
}

