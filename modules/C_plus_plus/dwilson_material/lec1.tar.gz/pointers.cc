#include <iostream>

using namespace std;

int main () {
  double *ptr = new double;

  *ptr = 3.14;

  cout << "ptr = " << ptr << endl;
  cout << "*ptr= " << *ptr << endl;

  double &x = *ptr;

  cout << "x = " << x << endl;

  cout << "&x = " << &x << endl;


  
  delete ptr;
  
  return 0;
}
