#include <iostream>

using namespace std;

int main () {

  double x = 3.14;
  
  double *ptr = &x;

  cout << "ptr = " << ptr << endl;
  cout << "*ptr= " << *ptr << endl;

  cout << "x = " << x << endl;
  
  double &y = x;

  cout << "y = " << y << endl;

  x=6.28;

  cout << "x = " << x << endl;
  cout << "y = " << y << endl;

  y = 0.707;

  cout << "x = " << x << endl;
  cout << "y = " << y << endl;

  
  return 0;
}
