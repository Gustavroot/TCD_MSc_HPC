#include <iostream>

using namespace std;

int main(){

  //insightful comment!
  
  cout << "Hello!" << /*cheeky comment*/ endl;

  /*
    longer
    comment
    ...*/
  
  return 0;
}


