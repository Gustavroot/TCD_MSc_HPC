#include <iostream>

using namespace std;

struct Thingy_t {
  const double pi = 3.141592653589;
  int two = 2;
  double x;
};

int main(){

  Thingy_t thingy;

  cout << "pi = " << thingy.pi << endl;

  cout << "two = " << thingy.two << endl;

  for (int i=0; i<3; i++){
    thingy.x = i;
    cout << thingy.x << endl;
  }
  
  return 0;
}
