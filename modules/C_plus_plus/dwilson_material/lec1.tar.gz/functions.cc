#include <iostream>

using namespace std;


double square( double x){
  return x*x;
}


double my_func( double &x){
  x++;
  return x;
}

int main () {

  for (int i=0; i<5; i++){
    cout << i << " " << square(i) << endl; 
  }

  double z = 0.5;
  for (int j=0; j<5; j++){
    double f = my_func(z);
    cout << "j=" << j << " f= " << f << " z= " << z << endl; 
  }
  
  return 0;
}

