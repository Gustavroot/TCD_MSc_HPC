#include <iostream>
//#include <math.h>

//using namespace std;

namespace thingy {
  const double pi = 3.141592653589;
}

int main(){
  
  cout << "Hello!" << endl;

  cout << "pi = " << thingy::pi << endl; 

  //cout << "pi = " << pi << endl; // fails
  
  return 0;
}


