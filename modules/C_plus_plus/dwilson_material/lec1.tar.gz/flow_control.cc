#include <iostream>

using namespace std;

int main () {
  
  for (int i = 0; i<10; i++){
    
    if ((i%2) == 0) {
      cout << i << " is even" << endl;
    } else {
      cout << i << " is odd" << endl;
    }
    
  }

  cout << endl;
  
  int j=0;
  while(j<10){

    cout << j << " ";

    switch(j){
    case 1:
      cout << "a" << endl;
      break;
    
    case 2:
      cout << "b" << endl;
      break;

    case 5:
      cout << "e" << endl;
      break;
      
    default:
      cout << j << endl;
      break;
    }
    
    j++; //j=j+1
  }

}
