#include<iostream>

using namespace std;

int fac( const int &n ){

  if (n<1) {
    cerr << "only defined for positive integers" << endl;
    exit(1);
  }

  int val = 1;

  if (n>1){
    val = n*fac(n-1);
  }

  return val;
}

int main(){

  cout << "factorial!" << endl;

  for (int i = 7; i>-1; i--){
    cout << "i = " << i << ", i!= " << fac(i) << endl;
  }
  
  return 0;
}
