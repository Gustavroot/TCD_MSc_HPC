#include <iostream>
#include <cmath>

using namespace std;

double sqrt_sign ( double x, short return_sign=1 ){

  return sqrt(x)*return_sign;

}

int main (){

  //pointer to a function that takes a double and a short int
  double (*ptr_fun)( double, short ) = &sqrt_sign;

  double z = ptr_fun(16,-1);
  cout << z << endl;

  return 0;
}
