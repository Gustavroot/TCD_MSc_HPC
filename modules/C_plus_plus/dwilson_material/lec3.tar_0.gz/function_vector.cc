#include <iostream>
#include <vector>
#include <cmath>
#include <sstream>

using namespace std;

double dot_v( const vector< double > &x){
  //vector dot product
  
  double val = 0;
  
  for (int i = 0; i<x.size(); i++){
    val += x[i]*x[i];
  }

  return sqrt(val);
}




vector<double> elem_inverses( const vector< double > &x){

  vector<double> inv(x.size());
  //initialise a new vector same size as x

  for (int i = 0; i<x.size(); i++){
    inv[i] = 1.0/x[i]; //each element is the inverse of x
  }
  
  return inv;
}




void v_string( const vector< double > &x){
  //write a vector terminal
  
  cout << "v= ( ";
  for(int i=0; i<x.size(); i++){cout << x[i] <<"  ";}
  cout << " )\n";
  
}




int main(){

  vector< double > v(3);
  v[0]=3.14159;
  v[1]=1.61803;
  v[2]=2.71828;

  cout << "v= ( ";
  for(int i=0; i<v.size(); i++){cout << v[i] <<"  ";}
  cout << " )\n";
  
  cout << "dot_v = " << dot_v(v) << endl << endl;

  v_string( v );
  v_string( elem_inverses( v ) );
  v_string( elem_inverses( elem_inverses( v ) ) );
  
  return 0;
}
