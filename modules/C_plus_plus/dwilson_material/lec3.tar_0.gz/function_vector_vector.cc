#include<iostream>
#include<vector>
#include<math.h>

using namespace std;



vector< vector<int> > funM( const vector< vector<int> > &M ){

  vector< vector< int > > valM;

  int size_i = M.size();
  int size_j = M[0].size();

  //cout << size_i << " " << size_j << endl;

  valM.resize(size_i);
  for (int i=0; i<size_i; i++){
    
    valM[i].resize(size_j); 

    for (int j=0; j<size_j; j++){
      valM[i][j] = i + M[i][j];
    }
  } 


  return valM;
}



int main(){

  vector< vector<int> > M;

  int size_i = 4;
  int size_j = 3;
  
  M.resize(size_i);
  for (int i=0; i<size_i; i++){
    M[i].resize(size_j);
  }

  for (int i=0; i<size_i; i++){
    for (int j=0; j<size_j; j++){
      M[i][j] = i+j;
    }
  }

  for (int j=0; j<size_j; j++){
    for (int i=0; i<size_i; i++){
      cout << M[i][j] << "  ";
    }
    cout << endl;
  }
  cout << endl;

  vector< vector< int> > newM = funM( M );
  
  //code more generically, use iterators
  //output is transposed
  for (vector < vector< int > >::const_iterator iter = newM.begin(); iter!=newM.end(); ++iter){

    vector<int> col = *iter; //dereference pointer, unnecessary, but might be clearer

    for( vector<int>::const_iterator iter_col = col.begin(); iter_col!= col.end(); ++iter_col) {
      
      cout << *iter_col << "   ";

    }
    cout << endl;
  }
}
