#include <iostream>
#include <cmath>

using namespace std;

double do_thing( double x ){

  static int i=0; //initialised only once

  cout << i;
  
  i++;
  
  return 10*x;

  //value of i at return is saved for the next call
}


int main(){

  for (int j=0; j<100; j++){

    cout << "j = " << j << ", i= ";
    double z = do_thing(1.0);
    cout << endl;
  }
  
  return 0;
}
