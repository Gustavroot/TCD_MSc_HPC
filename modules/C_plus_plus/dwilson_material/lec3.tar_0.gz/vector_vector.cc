#include<iostream>
#include<vector>
#include<math.h>

using namespace std;

int main(){

  vector< vector<int> > M;

  int size_i = 4;
  int size_j = 3;
  
  M.resize(size_i);
  for (int i=0; i<size_i; i++){
    M[i].resize(size_j);
  }

  for (int i=0; i<size_i; i++){
    for (int j=0; j<size_j; j++){
      M[i][j] = i+j;
    }
  }

  for (int j=0; j<size_j; j++){
    for (int i=0; i<size_i; i++){
      cout << M[i][j] << "  ";
    }
    cout << endl;
  }
  cout << endl;
}
