#include <iostream>
#include <cstdarg>

using namespace std;

// from http://en.cppreference.com/w/cpp/utility/variadic

void simple_printf(const char* fmt...){
  va_list args;
  va_start(args, fmt);

  int count=0;
    
  while (*fmt != '\0') {

    cout << "count = " << count << ", ";
      
    if (*fmt == 'd') {

      int i = va_arg(args, int);
      cout << i << '\n';

    } else if (*fmt == 'c') {

        // note automatic conversion to integral type
        c = va_arg(args, int);
	cout << static_cast<char>(c) << '\n';
      
    } else if (*fmt == 'f') {

      double d = va_arg(args, double);
      cout << d << '\n';

    }
    ++fmt;
    ++count;
  }
 
  va_end(args);
}
 
int main(){
  
  simple_printf("dcff", 4, 'a', 1.999, 42.5);

  return 0;
}
