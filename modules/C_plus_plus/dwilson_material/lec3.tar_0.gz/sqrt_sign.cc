#include <iostream>
#include <cmath>

using namespace std;

double sqrt_sign ( double x, short return_sign=1 ){

  return sqrt(x)*return_sign;
}


int main (){

  cout << sqrt_sign( 9, +1) << endl;
  cout << sqrt_sign( 9, -1) << endl;
  cout << sqrt_sign( 9 ) << endl;

  return 0;
}
