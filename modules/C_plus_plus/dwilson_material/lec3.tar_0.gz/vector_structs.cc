#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

struct my_new_type_t {
  vector< double > vec_d;
  vector< int > vec_i;
  int x;
};


void v_string( const vector< double > &x){
  //write a vector terminal
  
  cout << "v= ( ";
  for(int i=0; i<x.size(); i++){cout << x[i] <<"  ";}
  cout << " )\n";
  
}


int main(){
  
  my_new_type_t newTypeVar;

  vector< double > v(3);
  v[0]=3.14159;
  v[1]=1.61803;
  v[2]=2.71828;
  
  newTypeVar.x = 2;
  newTypeVar.vec_d = v;

  newTypeVar.vec_i.push_back(42);

  v_string( newTypeVar.vec_d );
  
  return 0;
}
