#include<iostream>

class Vector { 

private:
  
public:

  int sz;             // the size
  double* elem;       // a pointer to the elements
  
  Vector(int s) : sz{s},   // constructor
                  elem{new double[s]}  // allocates memory
  { 
    /* . . . */ 
  }

  ~Vector(){         // destructor
    delete[] elem;   // deallocates memory
  }
  /* . . . */
};



int main (){

  Vector my_vec(2);

  my_vec.elem[0]=10.1;
  my_vec.elem[1]=1;


  Vector my_new_vec = my_vec;
  
  std::cout << my_vec.elem[0] << std::endl;
  std::cout << my_vec.elem[1] << std::endl;

  std::cout << "new vector:" << std::endl;
  std::cout << my_new_vec.elem[0] << std::endl;
  std::cout << my_new_vec.elem[1] << std::endl;


  my_new_vec.elem[0]=12.1;
  my_vec.elem[1]=2;

  std::cout << my_vec.elem[0] << std::endl;
  std::cout << my_vec.elem[1] << std::endl;

  std::cout << "new vector:" << std::endl;
  std::cout << my_new_vec.elem[0] << std::endl;
  std::cout << my_new_vec.elem[1] << std::endl;
  
  //my_vec[0]=3;
  //my_vec[1]=6;
  
  return 0;
}
