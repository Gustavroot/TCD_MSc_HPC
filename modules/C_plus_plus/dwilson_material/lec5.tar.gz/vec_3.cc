#include<iostream>

class Vector { 

private:

  int sz;             // the size
  double* elem;       // a pointer to the elements
  
public:

  
  Vector(int s) : sz{s}, elem{new double[sz]} {
    for (int i = 0; i<sz; ++i) elem[i] = 0.0; //do initialisation
  }

  
  //deep assignment operator
  Vector& operator=(const Vector& vec_in) { 
    if (this == &vec_in){ return *this; }
    
    double* p = new double[vec_in.sz]; //allocate new memory
    std::copy(vec_in.elem, vec_in.elem + vec_in.sz, p); //does the copy

    elem = p; //reassign internal memory
    sz = vec_in.sz; //set internal size

    //delete[] elem; //deallocate old space
    
    return *this;
  }
  

  //initialise using a list
  Vector(std::initializer_list<double> lst)
    : sz{int(lst.size())}, elem{new double[sz]}
  {
    std::copy( lst.begin(),lst.end(),elem);
  }


  //do some output
  void print(){
    std::cout << "( ";
    for (int i = 0; i<sz; ++i){
      std::cout << elem[i] << " ";
    }
    std::cout << ")" << std::endl;
  }




  //summation operator - using copy
  Vector& operator+(const Vector& vec_a) {

    if (this->sz != vec_a.sz){
      std::cerr << "Vector size mismatch" << std::endl;
    }

    double* p = new double[vec_a.sz]; //allocates new memory

    for (int i=0;i<vec_a.sz;i++){
      p[i] = this->elem[i] + vec_a.elem[i];
    }
    
    elem = p; //reassign internal memory
    sz = vec_a.sz; //set internal size

    return *this;
  }




  
  // destructor
  ~Vector(){         
    delete[] elem;   // deallocates memory
  }
  
};



int main (){

  Vector my_vec = {0.0, 1.1, 2.2};

  Vector my_new_vec = {2,3,4};

  my_vec.print();
  my_new_vec.print();
  
  my_new_vec = my_vec + my_new_vec;

  my_new_vec.print();
  
  return 0;
}
