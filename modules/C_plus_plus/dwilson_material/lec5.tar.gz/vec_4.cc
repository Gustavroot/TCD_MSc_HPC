#include<iostream>

class Vector { 

public:
  
  int sz;             // the size
  double* elem;       // a pointer to the elements

  
  Vector(int s) : sz{s}, elem{new double[sz]} {
    for (int i = 0; i<sz; ++i) elem[i] = 0.0; //do initialisation
  }

  
  //deep assignment operator
  Vector& operator=(const Vector& vec_in) { 
    if (this == &vec_in){ return *this; }
    
    double* p = new double[vec_in.sz]; //allocate new memory
    std::copy(vec_in.elem, vec_in.elem + vec_in.sz, p); //does the copy

    elem = p; //reassign internal memory
    sz = vec_in.sz; //set internal size
    
    return *this;
  }
  

  //initialise using a list
  Vector(std::initializer_list<double> lst)
    : sz{int(lst.size())}, elem{new double[sz]}
  {
    std::copy( lst.begin(),lst.end(),elem);
  }


  //do some output
  void print(){
    std::cout << "( ";
    for (int i = 0; i<sz; ++i){
      std::cout << elem[i] << " ";
    }
    std::cout << ")" << std::endl;
  }

  //move constructor
  Vector(Vector&& vec_in) :    
    sz{vec_in.sz}, elem{vec_in.elem}  { 
      vec_in.elem = nullptr; //C++11 set original pointer to nothing
      vec_in.sz=0;
    }

  //move assignment
  Vector& operator=(Vector&& vec_in) { 
    if (this == &vec_in){ return *this; }    
    std::swap(elem, vec_in.elem);
    std::swap(sz, vec_in.sz);
    return *this; 
  }

  
  // destructor
  ~Vector(){         
    delete[] elem;   // deallocates memory
  }


  //summation operator - using copy
  Vector& operator+(const Vector& vec_a) {

    if (this->sz != vec_a.sz){
      std::cerr << "Vector size mismatch" << std::endl;
    }

    double* p = new double[vec_a.sz]; //allocates new memory

    for (int i=0;i<vec_a.sz;i++){
      p[i] = this->elem[i] + vec_a.elem[i];
    }
    
    elem = p; //reassign internal memory
    sz = vec_a.sz; //set internal size

    return *this;
  }


  //move assignment
  Vector& operator+(Vector&& vec_in) {
    
    if (this->sz != vec_in.sz){
      std::cerr << "Vector size mismatch" << std::endl;
    }
    

    return *this; 
  }


  
};



int main (){

  Vector my_vec = {0.0,1.1,2.2};

  Vector my_new_vec = {2,3,4,5};

  my_new_vec = my_vec;
  
  my_vec.print();
  my_new_vec.print();

  my_vec.elem[0]=2;
  my_vec.print();
  my_new_vec.print(); 

  my_new_vec = my_vec + my_vec;
  my_new_vec.print();
   
  return 0;
}
