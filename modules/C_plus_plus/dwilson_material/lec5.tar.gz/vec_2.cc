#include<iostream>

class Vector { 

public:

  int sz;             // the size
  double* elem;       // a pointer to the elements
  
  Vector(int s) : sz{s},  elem{new double[s]}{
    //...
  };

  //deep assignment operator
  Vector& operator=(const Vector& vec_in) { 
    if (this == &vec_in){ return *this; }
    
    double* p = new double[vec_in.sz]; //allocate new memory
    std::copy(vec_in.elem, vec_in.elem + vec_in.sz, p); //does the copy

    elem = p; //reassign internal memory
    sz = vec_in.sz; //set internal size
    
    return *this;
  }

  
  //deep copy constructor
  Vector(const Vector& vec_in) : 
    sz(vec_in.sz) { 
      if (vec_in.elem != 0) {
        elem = new double[sz]; 
        for (int i = 0;i<sz;i++){ elem[i]=vec_in.elem[i]; }
      } else {
        elem = 0;
      }
    }


  
  ~Vector(){         // destructor
    delete[] elem;   // deallocates memory
  }
  
};



int main (){


  Vector my_vec(2);

  my_vec.elem[0]=10.1;
  my_vec.elem[1]=1;


  Vector my_new_vec = my_vec;

  std::cout << "old vector:" << std::endl;
  std::cout << my_vec.elem[0] << std::endl;
  std::cout << my_vec.elem[1] << std::endl;

  std::cout << "new vector:" << std::endl;
  std::cout << my_new_vec.elem[0] << std::endl;
  std::cout << my_new_vec.elem[1] << std::endl;

  my_new_vec.elem[0]=12.1;
  my_vec.elem[1]=2;

  std::cout << "old vector:" << std::endl;
  std::cout << my_vec.elem[0] << std::endl;
  std::cout << my_vec.elem[1] << std::endl;

  std::cout << "new vector:" << std::endl;
  std::cout << my_new_vec.elem[0] << std::endl;
  std::cout << my_new_vec.elem[1] << std::endl;
  
  return 0;
}
