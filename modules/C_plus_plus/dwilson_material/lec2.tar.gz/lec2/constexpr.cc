#include<iostream>

using namespace std;


constexpr int func( const int &n ){
  return n*n + 1;
}

int main(){

  const int m = func(3); //computed at compile time

  cout << m << endl;
  
  return 0;
}


