#include <iostream>

using namespace std;

double *reverse_arr( double *arr, int arr_size){

  double *arr_temp = new double[arr_size];

  for (int i=0; i<arr_size;i++){
    arr_temp[i]=arr[arr_size-i-1];
    //cout << i << " " << arr_temp[i] << endl;
  }
  
  return arr_temp;
}


int main ()
{
   // an array with 5 elements.
   double arr[5] = {21,31,41,51,61};
   int arr_size = 5;
   
   double * new_arr = reverse_arr(arr, arr_size);

   
   for (int i=0; i<arr_size; i++){
     cout << "i = " << i
	  << ", arr_i = " << arr[i]  
	  << ", new_arr_i = " << new_arr[i] << endl;
   }

   //don't do this in C++!
   
   return 0;
}
