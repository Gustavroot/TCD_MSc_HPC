#include <iostream>
#include <chrono>
#include <ctime>

using namespace std;

long fibonacci(const long &n)
{
    if (n < 2) return n;
    return fibonacci(n-1) + fibonacci(n-2);
}

inline long fibonacci_inline(const long &n)
{
    if (n < 2) return n;
    return fibonacci_inline(n-1) + fibonacci_inline(n-2);
}


long long fac( const long long &n ){

  if (n<0) {
    cerr << "error\n"; exit(1);
  }

  long long val = 1;

  if (n>1){
    val = n*fac(n-1);
  }

  return val;
}


inline long long fac_inline( const long long &n ){
  
  if (n<0) {
    cerr << "error\n"; exit(1);
  }

  long long val = 1;

  if (n>1){
    val = n*fac_inline(n-1);
  }

  return val;
}



int main()
{

  for (int i=0; i<1; i++){

    cout << "Fibonacci function without/with inlining" << endl;
    
    chrono::time_point<std::chrono::system_clock> start, end;
    
    //run Fibonacci without inline
    start = chrono::system_clock::now();
    cout << "       fib(42) = " << fibonacci(42) << ", ";
    end = chrono::system_clock::now();
 
    chrono::duration<double> elapsed_seconds = end-start;
    cout << "elapsed time: " << elapsed_seconds.count() << "s\n";


    //run Fibonacci with inline
    start = chrono::system_clock::now();
    cout << "inline fib(42) = " << fibonacci_inline(42) << ", ";
    end = chrono::system_clock::now();

    elapsed_seconds = end-start;
    cout << "elapsed time: " << elapsed_seconds.count() << "s\n";

    cout << endl;



    
    cout << "Factorial function without/with inlining" << endl;
    
    //highest resolution clock
    chrono::time_point<std::chrono::high_resolution_clock> start_hr, end_hr;

    //run Factorial without inline
    start_hr = chrono::high_resolution_clock::now();
    cout << "       fac(20) = " << fac(20) << ", ";
    end_hr = chrono::high_resolution_clock::now();

    elapsed_seconds = end_hr - start_hr;
    cout << "elapsed time: " << 1.e9*elapsed_seconds.count() << "ns\n";

    //run Factorial with inline
    start_hr = chrono::high_resolution_clock::now();
    cout << "inline fac(20) = " << fac_inline(20) << ", ";
    end_hr = chrono::high_resolution_clock::now();

    elapsed_seconds = end_hr - start_hr;
    cout << "elapsed time: " << 1.e9*elapsed_seconds.count() << "ns\n";



    cout << endl << endl;

  }


  //time_t end_time = chrono::system_clock::to_time_t(end);
  //cout << "Finished at " << end_time;
}
