#include<iostream>  //input/output
#include<vector>    //vector
#include<math.h>    //sqrts etc
#include<algorithm> //sort

int main(){

  std::vector< int > v;

  //resize
  v.resize(3);

  //value assignment
  v[0]=12; v[1]=17; v[2]=4;

  //add an element to the end
  v.push_back(3);

  //get the number of elements
  std::cout << "num = " << v.size() << std::endl;
  
  //sort — very highly optimised
  //std::sort(v.begin(), v.end());

  //insert
  std::vector<int>::iterator it = v.begin() + 1; // insert 33 before the second element:
  v.insert(it, 33);

  //fancy iterators
  int i = 0;
  for ( std::vector<int>::iterator iter = v.begin(); iter != v.end(); ++iter){
    std::cout << "elem " << i << " = " << *iter << std::endl;
    ++i;
  }
  std::cout << std::endl << std::endl;

  
  //begin end are just pointers to the start and end of the data
  std::cout << "first = " << (*v.begin()) << ", last  = " << (*(v.end()-1)) << std::endl;
  std::cout << "size = " << v.size() << std::endl;
  std::cout << "also last = " << (*(v.begin() + v.size()-1) ) << std::endl;
  std::cout << std::endl;
  
  //delete stuff
  for ( std::vector<int>::const_iterator it2 = v.begin(); it2 != v.end(); ++it2){
    //std::cout << "*it2 = " << *it2 << std::endl;
    if (*it2 == 33){
      v.erase(it2);
      //careful resizes vector as we go, element *it2 gets shuffled down
      //eg another v.erase(it2); //will delete the next element too
      //v.erase(it2);
      break;
    }
  }

  std::cout << "after erase:" << std::endl;
  std::cout << "size = " << v.size() << std::endl;
  for ( std::vector<int>::iterator iter = v.begin(); iter != v.end(); ++iter){
    std::cout << "elem " << (iter-v.begin()) << " = " << *iter << std::endl;
  }

  //std=c++11 only - range based for loop:
  //for ( range_declaration : range_expression ) loop_statement

  //for (const int& i : v) { // access by const reference
  //for (auto i : v) { //use auto
  //  std::cout << i << ' ';
  //}
  //std::cout << '\n';
  
  //erase everything
  v.clear();
  std::cout << "after clear, size = " << v.size() << std::endl;


  return 0;
}
