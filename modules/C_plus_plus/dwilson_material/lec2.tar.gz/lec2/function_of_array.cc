#include <iostream>
#include <math.h> //for sqrt


using namespace std;



double arr_fun( double *arr, int arr_size){

  double val=0;

  for (int i=0; i<arr_size;i++){
    val+=arr[i]*arr[i];
  }
  
  return sqrt(val);
}


double dot_fun( double *arr1, double *arr2, int arr_size){

  double val=0;

  for (int i=0; i<arr_size;i++){
    val+= arr1[i]*arr2[i];
  }
  
  return sqrt(val);
}


int main ()
{
   // an array with 5 elements.
   double arr[5] = {21,31,41,51,61};
   double *ptr;

   ptr = arr;
 
   // output each array element's value 
   cout << "Array Elements : " << endl; 
   for ( int i = 0; i < 5; i++ )
   {
       cout << "*(ptr + "  << i << ") : ";
       cout <<  *(ptr + i) << endl;
   }

   cout << "... " << arr_fun( arr, 5) << endl;

   double arr_1[2]={1,2};
   double arr_2[2]={9,8};

   cout << "dot = " << dot_fun(arr_1,arr_2,2) << endl;
   
   return 0;
}
