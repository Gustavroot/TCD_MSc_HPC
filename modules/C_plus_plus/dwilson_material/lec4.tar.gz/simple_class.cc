class MyClass {

private:

  //stuff invisible externally: functions, data, etc.

public:

  //stuff that can be accessed externally
  
};


int main(){

  MyClass new_Object;
  
}
