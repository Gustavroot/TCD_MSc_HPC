#include "Vector.h"

int main(){

  int size_A = 3;
  Vector A(size_A);

  Vector B = {1.1,3.3, 6.2};
  
  A.print();
  B.print();

  std::cout << B(2)<< ", " << B.size() << std::endl;
  
  Vector C(size_A);

  C=B+A;

  std::cout << C;
  
  /*  while (true){
  C=B+A;
  }
  C.print();*/
  
  return 0;
  
}
