#include "Vector.h"

//constructor
Vector::Vector(int s) : sz{s}, elem{new double[sz]}
{
  for (int i = 0; i<sz; ++i) {
    elem[i] = 0.0; 
  }
}


//initialise using a list
Vector::Vector(std::initializer_list<double> lst) : sz{int(lst.size())}, elem{new double[sz]}
{
  std::copy( lst.begin(),lst.end(),elem);
}


//move constructor
Vector::Vector(Vector&& vec_in) : sz{vec_in.sz}, elem{vec_in.elem}
{ 
  vec_in.elem = nullptr; //C++11 set original pointer to nothing
  vec_in.sz=0;
}


//deep assignment operator
Vector& Vector::operator=(const Vector& vec_in) { 
  if (this == &vec_in){ return *this; }
  
  double* p = new double[vec_in.sz]; //allocate new memory
  std::copy(vec_in.elem, vec_in.elem + vec_in.sz, p); //does the copy

  delete[] this->elem; //free old memory 
  
  elem = p; //reassign internal memory
  sz = vec_in.sz; //set internal size
  
  return *this;
}


//move assignment
Vector& Vector::operator=(Vector&& vec_in) { 
  if (this == &vec_in){ return *this; }    
  std::swap(elem, vec_in.elem);
  std::swap(sz, vec_in.sz);
  return *this; 
}


//summation operator - using copy
Vector& Vector::operator+(const Vector& vec_a) {

  if (this->sz != vec_a.sz){
    std::cerr << "Vector size mismatch" << std::endl;
  }

  double* p = new double[vec_a.sz]; //allocates new memory

  for (int i=0;i<vec_a.sz;i++){
    p[i] = this->elem[i] + vec_a.elem[i];
  }

  delete[] this->elem; //free old memory
  
  elem = p; //reassign internal memory
  sz = vec_a.sz; //set internal size

  return *this;
}



//do some output
void Vector::print(){
  std::cout << "( ";
  for (int i = 0; i<sz; ++i){
    std::cout << elem[i] << " ";
  }
  std::cout << ")" << std::endl;
}

double Vector::operator()(const int i){ //access ith element
  return this->elem[i];
}

int Vector::size(){
  return this->sz;
}


//destructor
Vector::~Vector(){         
  delete[] elem;   // deallocates memory
}







//output to stream -- note not a part of the class
std::ostream& operator<<(std::ostream &os, Vector& vec_in){
  
  os << "( ";
  for (int i = 0; i<vec_in.size(); ++i){
    os << vec_in(i) << " ";
  }
  os << ")" << std::endl;
  return os;
}
