#include<iostream>

class Vector { 
  
public:

  // constructors
  Vector(int s);                             // standard deep constructor
  Vector(Vector&& vec_in);                   // move constructor
  Vector(std::initializer_list<double> lst); // initialiser list constructor
  
  // operators
  Vector& operator=(const Vector& vec_in);   // deep assignment operator
  Vector& operator=(Vector&& vec_in);        // move assignment
  Vector& operator+(const Vector& vec_a);    // summation operator

  void print();                              // do some output 
  
  // everything up to here was covered in the lectures/examples so far

  // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---  
  
  // many new things will be needed to make a relatively complete class, for example:

  //access ith element
  double operator()(const int i); 
  
  // logical operators
  bool operator==(const Vector& vec_a);    // true if vec_a==vec_b
  bool operator!=(const Vector& vec_a);    // true if vec_a!=vec_b
  bool operator<(const Vector& vec_a);     // not necessarily mathematically useful
  // note: if we define "<" this object can be used as a std::map key
  // if a!=b then define vec_a>vec_b or vec_a<vec_b -- some element by element function.

  
  // stream operators - defined outside class
  // can define here also using "friend" which permits private access



  // Vector arithmetic
  Vector& operator-(const Vector& vec_a);     // difference operator
  Vector& operator+=(const Vector vec_a);     // operator to perform A+=B (same as A=A+B)
  Vector& operator-=(const Vector vec_a);     // operator to perform A-=B (same as A=A-B)
  Vector& operator*(const double& rescaling); // multiply each element by a rescaling factor vec_a.elem[i]*rescaling


  // functions
  int size();                                           // standard library-like size(), returns a const "sz".
  double dot(const Vector& vec_a, const Vector& vec_b); // vector dot product
  double modulus(const Vector& vec_a);                  // vector modulus
  Vector push_back(const double& new_element);          // increase size by 1, push a new entry on to the end.
  Vector resize(const int& new_size);                   // adjust size of vector - might need delete/new pair

  
  // destructor
  ~Vector();   //deletes the array stored at *elem

  //many more things are possible:
  // - various iterators as in standard library
  // - pointers to start and end elements as in standard library
  // - delete, insert elements.
  // - swap, clear, sort, find type functions 
  
private:
  
  int sz;             // the number of elements
  double* elem;       // a pointer to the elements
  
};



//Non-class stuff
std::ostream& operator<<(std::ostream &os, Vector& vec_in);
