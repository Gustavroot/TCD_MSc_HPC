#include <iostream>
#include <string>

using namespace std;

class B; //forward declaration

class A {
  friend class B;
  
private:
  string secrets = "shhh";
};

class B {
public:
  void gossip( A objA ){
    cout << objA.secrets << endl;
  }
};

  
int main () {

  A objA;
  B objB;

  objB.gossip(objA);
  
  return 0;
}
