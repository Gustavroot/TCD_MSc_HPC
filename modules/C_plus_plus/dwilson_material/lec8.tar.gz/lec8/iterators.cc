#include<iostream>
#include<vector>
#include<list>

using namespace std;

int main(){

  //old school
  double a[10];

  for (int i = 0; i<10; i++){
    a[i] = double(i)*3.14;
    cout << a[i] << "    ";
  }
  cout << endl;

  //standard lib iterator
  vector<double> av(10);

  for (vector<double>::iterator it =  av.begin(); it!=av.end(); ++it){
    (*it) = double(it-av.begin())*3.14;
    cout << (*it) << "    ";
  }
  cout << endl;

  //how is this better??
}
