#include<iostream>

using namespace std;

class myBase 
{
public:
  // some virtual methods
  virtual void do_a_thing(){
    cout << "doing thing" << endl;
  }

  ~myBase(){
    cout << "Using base destructor" << endl;
  }
    
};

class myDerived : public myBase
{
public:
  ~myDerived()
  {
    cout << "Using derived destructor" << endl;
  }
};

int main(){

    

  myBase *b = new myDerived();
  // use b
  delete b;

  myDerived *c = new myDerived();
  // use c
  delete c; 

}
