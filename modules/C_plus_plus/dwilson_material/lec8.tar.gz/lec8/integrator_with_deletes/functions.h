

//abstract integrand class
class integrandF {

 public:
  virtual double f( double )=0;
  virtual ~integrandF(){};
};

//instantiable derived classes
class fn_exp : public integrandF {

 public:
  double f(double x);

};

class fn_sin : public integrandF {

 public:
  double f(double x);

};

class fn_poly : public integrandF {

 public:
  double f(double x);

};
