#include<iostream>
#include<cmath>

#include "integrator.h"

using namespace std;



int main(){


  
  cout << "test functions" << endl;
  fn_exp my_fn_exp; fn_sin my_fn_sin; fn_poly my_fn_poly;

  cout << "e^1 = "       << my_fn_exp.f(1.0) << endl;
  cout << "sin(pi/2) = " << my_fn_sin.f(3.1415926535898/2.0) << endl;
  cout << "poly(1) = "   << my_fn_poly.f(1.0) << endl;

  cout << endl;
  
  {
    cout << "test integrator" << endl;
    intRect my_integrator; //rectangle version
  
    double answer = my_integrator.integrate( my_fn_exp );

    cout << "answer = " << answer << endl;
  }




  while( true ){
    cout << "loop!"<< endl;
    genericIntegrator *gInt;
    integrandF *intF;
  

    gInt = new intTrapz; //trapz version
    intF = new fn_sin;
   
  
    cout << "factory ans = " << (*gInt).integrate( *intF ) << endl;

    //delete gInt;
    //delete intF;

  }
  
}

