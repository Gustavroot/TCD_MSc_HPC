#include "integrator.h"

double intRect::integrate( integrandF &fin ){

  int n = 10;
  double xmin=0.0; double xmax=1.0;
  double sum = 0.0;
  double delta = (xmax-xmin)/double(n);

  //uses rectangle midpoint
  for (int i = 0; i<n; ++i){
    double x = xmin + delta*double(i) + delta/2;
    sum += fin.f(x);
  }

  return sum*delta;
}


double intTrapz::integrate( integrandF &fin ){

  int n = 9;
  double xmin=0.0; double xmax=1.0;
  double sum = 0.0;
  double delta = (xmax-xmin)/double(n);

  //treat endpoints differently:
  sum += 0.5*fin.f(xmin);
  sum += 0.5*fin.f(xmax);
  
  //note the points n are different to intRect
  for (int i = 1; i<n; ++i){
    double x = xmin + delta*double(i);
    sum += fin.f(x);
  }

  return sum*delta;
  
  return 0.0;
}

// more method, intGauss, monte-carlo, ...
// convergence checks, error estimates, ...
