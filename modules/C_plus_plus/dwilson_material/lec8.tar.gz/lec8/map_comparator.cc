#include<iostream>
#include<map>
#include<vector>
#include<string>

using namespace std;

struct mapKey {
  double x;
  int d;
  std::string text;
  bool operator<(const mapKey &rhs) const;
};

bool mapKey::operator<(const mapKey &rhs) const {
  if (this->x!= rhs.x){ return this->x < rhs.x; }
  else if (this->d!= rhs.d) { return this->d < rhs.d; }
  else if (this->text!= rhs.text) { return this->text < rhs.text; }
  return false;
}


  
int main(){

  mapKey mK;

  mK.text = "blah";

  map< mapKey, double > myMap;

  for (int d=0; d<10;d++){
    mK.d = d;
    mK.x = 2*d + 0.1;
    myMap.insert( make_pair( mK, double(d+100) ) );
  }

  cout << "size = " << myMap.size() << endl;
    
  mK.d=5;
  mK.x=10.1;

  cout << myMap.find(mK)->second << endl;


  //again iterator works completely generically
  for ( map< mapKey, double >::const_iterator it = myMap.begin(); it!=myMap.end(); ++it){
    cout << "key.d = " << (*it).first.d << ", key.x = " << (*it).first.x << ", value = " << (*it).second << endl;
  }  
  
  return 0;
}
