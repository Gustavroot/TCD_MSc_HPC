#include<iostream>
#include<vector>
#include<list>
#include<map>
#include<unordered_map>

using namespace std;

int main(){

  //old school
  double a[10];

  for (int i = 0; i<10; i++){
    a[i] = double(i)*3.14;
    cout << a[i] << "    ";
  }
  cout << endl;

  //standard lib iterator
  vector<double> av(10);

  for (vector<double>::iterator it =  av.begin(); it!=av.end(); ++it){
    (*it) = double(it-av.begin())*3.14;
    cout << (*it) << "    ";
  }
  cout << endl;

  //how is this better??

  //very general
  map< int, double > am;
  unordered_map< int, double > aum;
  list< double > al;
  
  for (int i=0;i<10;i++){
    double val =  double(i)*3.14;
    am.insert( make_pair( i, val ) );
    aum.insert( make_pair( i, val ) );
    al.push_front( val );
  }

  cout<<"map:           ";
  for (map< int, double >::const_iterator it =  am.begin(); it!=am.end(); ++it){
    cout << (*it).second << "    ";
  }
  cout << endl;

  cout<<"unordered_map: ";
  for (unordered_map< int, double >::const_iterator it =  aum.begin(); it!=aum.end(); ++it){
    cout << (*it).second << "    ";
  }
  cout << endl;

  cout<<"list:          ";
  for (list< double >::const_iterator it =  al.begin(); it!=al.end(); ++it){
    cout << (*it) << "    ";
  }
  cout << endl;


  //more generic code:
  cout<<"more generic:  ";
  typedef list<double> myContainer; //eg swap for list, ...
  myContainer mc;

  mc = al;

  //nothing needs to change:
  for (myContainer::const_iterator it = mc.begin(); it!=mc.end(); it++){
    cout << (*it) << "    ";
  }
  cout << endl;
}
