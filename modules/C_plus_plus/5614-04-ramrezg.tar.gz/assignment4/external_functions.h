#include "grid.h"



//Code imlementing one sweep, with all possible outcomes
//from each sub-step or the sweep
void evolve_one_sweep(Grid&, int&);
