#include "sys/time.h"

typedef double VAR_TYPE;

#ifdef __cplusplus
extern "C" {
  VAR_TYPE cyl_rad_cu(VAR_TYPE*, VAR_TYPE*, VAR_TYPE*, int, int, double*, int, int, int);
}
#endif
