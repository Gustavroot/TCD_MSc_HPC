#include "sys/time.h"

typedef double VAR_TYPE;

#ifdef __cplusplus
extern "C" {
  VAR_TYPE norms_cu(VAR_TYPE*, int, int, double*, int, int, int);
}
#endif
