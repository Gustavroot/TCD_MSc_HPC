#!/bin/bash

rm -R hpl-2.1 2> /dev/null
rm compile_out.txt 2> /dev/null
rm -R makefiles 2> /dev/null
