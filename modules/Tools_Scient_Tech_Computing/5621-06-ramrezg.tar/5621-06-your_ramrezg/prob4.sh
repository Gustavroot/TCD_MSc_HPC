#!/bin/bash

nr_steps=100
if ! [ -z $1 ]
then
    #TODO: validate user input
    nr_steps=$1
fi

ctr_y=0
ctr_n=0

for i in $(seq $nr_steps)
do
    #position for 'y' or 'n' chars
    outp=$(./src_prob4/simple_mc $RANDOM)
    j=$((${#outp}-2))

    j_bool="${outp:$j:1}"
    if [ "$j_bool" = "y" ]
    then
        ((ctr_y++))
    else
        ((ctr_n++))
    fi
done

echo
accept_r=$(echo "scale=2; $ctr_y / ($ctr_y + $ctr_n) " | bc -l)
echo "Acceptance ratio: 0$accept_r"
echo
