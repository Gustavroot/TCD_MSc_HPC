#!/bin/bash


total_nrs=6
total_range=45


#Increases with each actual non-repeated lottery number
general_ctr=0

while [ $general_ctr -lt $total_nrs ]
do
    #create random number
    rnd=$(( ( RANDOM % $total_range )  + 1 ))

    #check if array is empty
    if [ -z "$ARRAY" ]
    then
        ARRAY[0]="$rnd"
        ((general_ctr++))
    else
        #check that random number is not equal to previous ones
        i=0
        while [ $i -lt ${#ARRAY[@]} ]
        do
            if [ $rnd -eq ${ARRAY[i]} ]
            then
                break
            else
                ((i++))
            fi
        done

        #if True, means no repetitions
        if [ $i -eq ${#ARRAY[@]} ]
        then
            #increase counter and append
            ARRAY[$general_ctr]="$rnd"
            ((general_ctr++))
        fi
    fi

done

#print resulting array of randoms
i=0
echo -e "\nResulting list of randoms:"
echo -e "($total_nrs numbers between 1 and $total_range)\n"
while [ $i -lt ${#ARRAY[@]} ]
do
    echo ${ARRAY[$i]}
    ((i++))
done
echo
