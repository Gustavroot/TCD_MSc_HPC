#!/bin/bash

#USAGE: ./prob6.sh DIR_NAME [-l -U]
#(-l for lowercase and -U for uppercase)

if [ -z $1 ]
then
    echo "Input param needed."
    exit
fi

input_dir=$1

if ! [ -d "$input_dir" ]
then
    echo "Directory doesn't exist!"
    exit
fi

let_case="-U"
if ! [ -z $2 ]
then
    if [ "$2" = "-l" ]
    then
        let_case="-l"
    fi
fi

#change to lower or uppercase, depending on $let_case
for file in $(ls $input_dir)
do
    filename=$(basename "$file")
    extension="${filename##*.}"
    filename="${filename%.*}"

    if [ "$let_case" = "-l" ]
    then
        out_name=$(echo $filename | awk '{print tolower($0)}')
    else
        out_name=$(echo $filename | awk '{print toupper($0)}')
    fi

    mv "$input_dir$file" "$input_dir$out_name.$extension" 2> /dev/null
done

