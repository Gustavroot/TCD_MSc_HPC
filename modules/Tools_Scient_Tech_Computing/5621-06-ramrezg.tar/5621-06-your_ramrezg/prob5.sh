#!/bin/bash

#NOTE: working on .txt files only

in_file="src_prob5/Hamlet.txt"
if ! [ -z $1 ]
then
    in_file=$1
fi

if ! [[ -e $in_file ]]
then
    echo "File doesn't exist!"
    echo
    exit
fi

echo

#zip compression
out_file="${in_file/.txt/}.zip"
zip -r $out_file $in_file > /dev/null

#gzip compression
out_file="${in_file/.txt/}.gz"
gzip -c $in_file > $out_file

#bzip2 compression
out_file="${in_file/.txt/}.bz2"
bzip2 -c $in_file > $out_file

#xz compression
out_file="${in_file/.txt/}.xz"
xz -c $in_file > $out_file

#size of files
orig_size=$(stat -c%s $in_file)
zip_size=$(stat -c%s ${in_file/.txt/.zip})
gzip_size=$(stat -c%s ${in_file/.txt/.gz})
bzip2_size=$(stat -c%s ${in_file/.txt/.bz2})
xz_size=$(stat -c%s ${in_file/.txt/.xz})

#echo $orig_size
comp_rate=$(echo "scale=2; $zip_size / $orig_size " | bc -l)
echo "-- zip compression rate: 0$comp_rate"
echo -e "\tfinal size: $zip_size"
comp_rate=$(echo "scale=2; $gzip_size / $orig_size " | bc -l)
echo "-- gzip compression rate: 0$comp_rate"
echo -e	"\tfinal size: $gzip_size"
comp_rate=$(echo "scale=2; $bzip2_size / $orig_size " | bc -l)
echo "-- bzip2 compression rate: 0$comp_rate"
echo -e	"\tfinal size: $bzip2_size"
comp_rate=$(echo "scale=2; $xz_size / $orig_size " | bc -l)
echo "-- xz compression rate: 0$comp_rate"
echo -e	"\tfinal size: $xz_size"

echo
