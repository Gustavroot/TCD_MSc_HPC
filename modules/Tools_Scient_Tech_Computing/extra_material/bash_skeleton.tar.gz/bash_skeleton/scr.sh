echo "this"
${gg:?}
echo "that"
