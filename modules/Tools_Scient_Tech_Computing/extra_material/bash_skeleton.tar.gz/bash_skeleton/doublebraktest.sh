#!/bin/bash

file=/etc/passwd
## Assumes that we are in examples dir
otherfile=Hamlet.*

if [[ -e $file ]]
then
  echo "Password file exists."
fi

if [[ -e Hamlet.* ]]
then
  echo "Double bracket: file matched"
fi

if [ -e Hamlet.* ] 
then
  echo "Single bracket: file matched"
fi
