#!/bin/bash 
RETVAL=0
ls
cd .
gsdde
cd .
