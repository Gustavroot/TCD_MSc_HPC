#!/bin/bash 
RETVAL=0
case "$1" in
    start)
	echo "Starting now..."
	;;
    stop)
	echo "Stopping now..."
	;;
    restart)
	echo "Stopping now..."
	echo "Starting now..."
	;;
    *)
	echo "Usage: $0 {start|stop|restart}"
	RETVAL=1
esac
exit $RETVAL
