#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#include "defs.h"
#include "options.h"


int parse_opts(int argc, char *argv[]) {
	int c;

	// set defaults
	opts.l = 4;
	opts.m = 4;
	opts.n = 4;
	opts.block_len = 10;
	opts.verbose = 0;   // non-verbose by default


	while ((c = getopt (argc, argv, "vl:m:n:b:")) != -1)
		switch(c) {
			case 'v':
				opts.verbose = 1; break;
			case 'l':
				opts.l = atoi(optarg); break;
			case 'm':
				opts.m = atoi(optarg); break;
			case 'n':
				opts.n = atoi(optarg); break;
			case 'b':
				opts.block_len = atoi(optarg); break;
			default:
				fprintf(stderr, "Invalid option given\n");
				return -1;
		}

	// small sanity check
	if (opts.l<=0 || opts.m<=0 || opts.n<=0) {
		fprintf(stderr, "Invalid matrix size - all sizes must be positive\n");
		return -1;
	}

	return 0;
}


/*
 * vim:ts=4:sw=4
 */
