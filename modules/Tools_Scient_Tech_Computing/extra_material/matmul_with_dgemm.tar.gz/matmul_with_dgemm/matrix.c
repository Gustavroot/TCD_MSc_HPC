#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "defs.h"
#include "matrix.h"


double ** alloc_square_matrix(int n) {
	return alloc_matrix(n, n);
}

double ** alloc_matrix(int height, int width) {
	double **matrix;
	double *matrix_data;	// use single 1-D matrix trick
	int i;

	if((matrix = (double **)malloc(height*sizeof(double *))) == NULL) {
		fprintf(stderr, "Can't malloc matrix of size (%d,%d)\n", height, width);
		exit (2);
	}

	// allocate the 2-D grid as a 1-D array
	if((matrix_data = (double *)malloc(width*height*sizeof(double))) == NULL) {
		fprintf(stderr, "Can't malloc matrix_data\n");
		return NULL;
	}
	memset((void *)matrix_data, 0, width*height*sizeof(double));

	// now correct the pointers of matrix to sit at the correct locations in the array
	for(i=0; i<height; i++) {
		matrix[i] = &matrix_data[i*width];
	}

	return matrix;
}

void init_rand_matrix(double **matrix, int height, int width) {
	int i,j;
	for(i=0;i<height;i++) {
		for(j=0;j<width;j++) {
			// get the next random number from the GSL library
			matrix[i][j] = (drand48() * MAX_VAL * 2) - MAX_VAL;
		}
	}
}

void print_matrix(double **matrix, int height, int width) {
	int i, j;
	for(i=0;i<height;i++) {
		for(j=0;j<width;j++) {
			printf("  %+11.6f ", matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

/*
 * Use the block method to multiply the two matrices.
 * We want to organise the order of multiplication of the blocks to ensure that matrix A's
 * blocks are cacheable as much as possible.
 * The matrix B's blocks are re-visited every nblocks.
 */
void matrix_multiply_block(double **C, double **A, double **B, int l, int m, int n, int block_len) {
	int i, j, k;		// inner loop indices
	int alpha, beta, gamma;	// block indices

	int q, r, s;		// block lengths corresponding to l, m, n respectively
	int nblocks_l, nblocks_m, nblocks_n;		// number of blocks corresponding to l, m, n respectively

	q = r = s = block_len;	// all the same

	// we've already checked that these divide evenly
	nblocks_l = (int)(l / block_len);
	nblocks_m = (int)(m / block_len);
	nblocks_n = (int)(n / block_len);

	if (DEBUG) {
		printf("sizes:       %d, %d, %d\n", l, m, n);
		printf("block sizes: %d, %d, %d\n", q, r, s);
		printf("num blocks:  %d, %d, %d\n", nblocks_l, nblocks_m, nblocks_n);
	}

	// first make sure that C is zeroed before we start adding
	// zeroing the matrix is easy since we've allocated the grid as a 1-D array
	memset((void *)C[0], 0, l*n*sizeof(double));

	for (gamma=0; gamma<nblocks_n; gamma++) {
		for (alpha=0; alpha<nblocks_l; alpha++) {
			for (beta=0; beta<nblocks_m; beta++) {
				if (DEBUG)
					printf("MULTIPLYING: A[%02d,%02d] with B[%02d,%02d]\n", alpha, gamma, gamma, beta);

				// now the actual multiplications in the block
				for (i=alpha*q; i<(alpha+1)*q; i++) {
					for (j=beta*r; j<(beta+1)*r; j++) {
						if (DEBUG)
							printf("\tBLOCK: C%02d,%02d", i,j);
						for (k=gamma*s; k<(gamma+1)*s; k++) {
							if (DEBUG)
								printf("+= A%02d,%02d * B%02d,%02d", i,k, k,j);
							C[i][j] += A[i][k] * B[k][j];
						}
						if (DEBUG)
							printf("\n");
					}
				}


			}
			if (DEBUG)
				printf("\n\n");
		}
	}

}

/*
 * take care of whether C == A or C = B. if so, we have to create a temporary
 * matrix to store the values, and then copy back. otherwise just proceed
 * note for simplicity, we're not checking fully for overlap, just the starting
 * positions.
 */
void matrix_multiply(double **C, double **A, double **B, int l, int m, int n) {
	int i, j, k;
	double **tmp_m;

	// does C refer to the same starting address as A or B?
	if (&C[0] == &A[0] || &C[0] == &B[0]) {
		// must use temporary storage
		tmp_m = alloc_matrix(l,n);

		for (i=0; i<l; i++) {
			for (j=0; j<n; j++) {
				tmp_m[i][j] = 0.0;
				for (k=0; k<m; k++) {
					tmp_m[i][j] += A[i][k] * B[k][j];
				}
			}
		}

		// now put the answers where they should be
		matrix_copy(C, tmp_m, n, n);
		// and tidy up
		free(tmp_m);
	} else {
		// assume no overlap - ok to proceed
		for (i=0; i<l; i++) {
			for (j=0; j<n; j++) {
				C[i][j] = 0.0;
				for (k=0; k<m; k++) {
					C[i][j] += A[i][k] * B[k][j];
				}
			}
		}
	}

}

/* calculate b = A * u
 * using a more specialised matrix*vector function, to avoid a third inner loop */
void matrix_vector_multiply(double *b, double **A, double *u, int m, int n) {
	int i, j;

	for (i=0; i<m; i++) {
		b[i] = 0.0;
		for (j=0; j<n; j++) {
			b[i] += A[i][j] * u[j];
		}
	}
}

/* set all matrix entries to 0 */
void matrix_zeros(double **matrix, int height, int width) {
	// zeroing the matrix is easy since we've allocated the grid as a 1-D array
	memset((void *)matrix[0], 0, width*height*sizeof(double));
}

/* set M to be an n*n identity matrix */
void identity_matrix(double **matrix, int n) {
	int i;

	// zeroing the matrix is easy since we've allocated the grid as a 1-D array
	memset((void *)matrix[0], 0, n*n*sizeof(double));

	for (i=0; i<n; i++)
		matrix[i][i] = 1.0;
}

void matrix_copy(double **Dest, double **Src, int m, int n) {
	// copy is very easy since we've allocated the grid as a 1-D array
	// note that Dest and Src cannot overlap
	memcpy(&Dest[0][0], &Src[0][0], (m*n*sizeof(double)));
}

/* assuming the matrix is square */
void matrix_transpose(double **Dest, double **Src, int n) {
	int i, j;

	for (i=0; i<n; i++)
		for (j=0; j<n; j++)
			Dest[j][i] = Src[i][j];
}

/*
 * vim:ts=4:sw=4
 */
