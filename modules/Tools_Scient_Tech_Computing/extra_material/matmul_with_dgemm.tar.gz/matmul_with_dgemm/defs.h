#ifndef __DEFS_H__
#define __DEFS_H__

#define MAX_VAL 1

#define DEBUG 0

struct s_options {
	int l;
	int m;
	int n;
	int block_len;
	int verbose;
} opts;


#endif

/*
 * vim:ts=4:sw=4
 */
