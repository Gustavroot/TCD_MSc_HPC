#ifndef __OPTIONS_H__
#define __OPTIONS_H__

int parse_opts(int, char **);

#endif

/*
 * vim:ts=4:sw=4
 */
