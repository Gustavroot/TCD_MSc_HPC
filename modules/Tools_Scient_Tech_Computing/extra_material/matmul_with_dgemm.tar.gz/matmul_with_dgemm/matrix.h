#ifndef __MATRIX_H__
#define __MATRIX_H__

double ** alloc_matrix(int, int);
double ** alloc_square_matrix(int);
void init_rand_matrix(double **, int, int);
void print_matrix(double **, int, int);
void matrix_multiply_block(double **, double **, double **, int, int, int, int);
void matrix_multiply(double **, double **, double **, int, int, int);
void matrix_vector_multiply(double *, double **, double *, int, int);
void matrix_zeros(double **, int, int);
void identity_matrix(double **, int);
void matrix_copy(double **, double **, int, int);
void matrix_transpose(double **, double **, int);

#endif

/*
 * vim:ts=4:sw=4
 */
