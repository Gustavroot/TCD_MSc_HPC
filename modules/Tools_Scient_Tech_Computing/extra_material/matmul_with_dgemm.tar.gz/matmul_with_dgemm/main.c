#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <sys/time.h>

#include "defs.h"
#include "options.h"
#include "matrix.h"

////////////////////////////////////////////////////////////////////////////////
// which BLAS library to use?
////////////////////////////////////////////////////////////////////////////////

//////////
// for GSL:
#include "gsl/gsl_cblas.h"

//////////
// for MKL:
//#include "mkl_cblas.h"

//////////
// for ACML:
//#include "acml.h"

////////////////////////////////////////////////////////////////////////////////


void usage(const char *appname) {
	fprintf(stderr, "usage: %s [-l size] [-m size] [-n size] [-v]\n", appname);
}

int main(int argc, char *argv[]) {

	struct timeval start, end;
	long elapsed;

	double **A, **B, **C;

	gettimeofday(&start, NULL);

	if(parse_opts(argc, argv) != 0) {
		//fprintf(stderr, "Problems with parse_opts - bailing out\n");
		usage(argv[0]);
		return -1;
	}

	// allocate space for the system first

	A = alloc_matrix(opts.l, opts.m);
	if(A == NULL) {
		fprintf(stderr, "Problems with alloc_matrix - bailing out\n");
		return -2;
	}

	B = alloc_matrix(opts.m, opts.n);
	if(B == NULL) {
		fprintf(stderr, "Problems with alloc_matrix - bailing out\n");
		return -3;
	}

	C = alloc_matrix(opts.l, opts.n);
	if(C == NULL) {
		fprintf(stderr, "Problems with alloc_matrix - bailing out\n");
		return -4;
	}

	// now initialise the matrices
	init_rand_matrix(A, opts.l, opts.m);
	init_rand_matrix(B, opts.m, opts.n);

	if (opts.verbose) {
		printf("========== Matrix A ==========\n");
		print_matrix(A, opts.l, opts.m);
		printf("========== Matrix B ==========\n");
		print_matrix(B, opts.m, opts.n);
	}

	//matrix_multiply(C, A, B, opts.l, opts.m, opts.n);
	//matrix_multiply_block(C, A, B, opts.l, opts.m, opts.n, opts.block_len);


	////////////////////////////////////////////////////////////////////////////////
	// more BLAS fun - the function signature is slightly different
	////////////////////////////////////////////////////////////////////////////////

	// for ACML:
	//dgemm('N', 'N', opts.l, opts.n, opts.m,

	// for GSL or MKL:
	cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, opts.l, opts.n, opts.m,
			1.0,				// ALPHA
			&A[0][0], opts.l,	// A and LDA
			&B[0][0], opts.n,	// B and LDB
			1.0,				// BETA
			&C[0][0], opts.l);	// C and LDC

	if (opts.verbose) {
		printf("========== Matrix C ==========\n");
		print_matrix(C, opts.l, opts.n);
	}

	gettimeofday(&end, NULL);
	elapsed = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);

	printf("%d %d %d %ld\n", opts.l, opts.m, opts.n, elapsed/1000);	// milliseconds

	return(0);
}



/*
 * vim:ts=4:sw=4
 */
