#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <math.h>	


//NOTE:
//	kilo = 10^3	2^10
//	mega = 10^6	2^20
//	giga = 10^9	2^30
//	tera = 10^12	2^40
//	peta = 10^15	2^50
//	exa = 10^18	2^60

//	1k = 10^3
//	1K = 2^10



//Core functions



//Secondary functions

//function to print usage, in case of miscall to the program
void print_usage(){
  printf("Usage: ./round [-FLAG] INTEGER\n");
}


//main code
int main(int argc, char *argv[]){
  long int N = -1, divider = -1;
  int i;
  int base_divider = 1024, option = 0, label = -1;
  char labels[6] = {'K', 'M', 'G', 'T', 'P', 'E'};

  //printf("%c\n", labels[2]);
  
  if(argc>3 || argc == 1){
    print_usage();
    return 0;
  }
  
  while ((option = getopt(argc, argv,"K:M:G:T:P:E:h:")) != -1) {
    switch (option) {
      case 'K' : divider = base_divider;
        N = strtol(optarg, NULL, 0);
        break;
      case 'M' : divider = base_divider*pow(2, 10);
        N = strtol(optarg, NULL, 0);
        break;
      case 'G' : divider = base_divider*pow(2, 20);
        N = strtol(optarg, NULL, 0);
        break;
      case 'T' : divider = base_divider*pow(2, 30);
        N = strtol(optarg, NULL, 0);
        break;
      case 'P' : divider = base_divider*pow(2, 40);
        N = strtol(optarg, NULL, 0);
        break;
      case 'E' : divider = base_divider*pow(2, 50);
        N = strtol(optarg, NULL, 0);
        break;
      case 'h' : divider = 1;
        N = strtol(optarg, NULL, 0);
        break;
      //if no flag nor integer
      default:
        print_usage();
        return 0;
    }
    label = option;
  }
  if(label == -1){
    divider = base_divider;
    N = strtol(argv[1], NULL, 0);
    label = 'K';
  }
  
  if(N == -1 || divider == -1){
    print_usage();
    return 0;
  }

  //TODO: following if: check here if N is not integer
  //printf();
  //if (/* ! */) {
  //  print_usage();
  //  return 0;
  //}

  if(label == 'h'){
    for(i = 0; i<6; i++){
      divider = base_divider*pow(2, i*10);
      //TODO: check and put here the appropriate limit to "human-readability"
      if( (int)((double)N/(double)divider) < 25.0 ){
        label = labels[i];
        break;
      }
    }
  }

  printf("%ld = %.1f%c\n", N, (double)N / (double)divider, label);

  return 0;
}
