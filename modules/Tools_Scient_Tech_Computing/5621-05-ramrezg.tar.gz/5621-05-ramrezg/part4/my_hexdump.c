#include <stdio.h>


int main(){
  printf("Blah.\n");

  return 0;
}
