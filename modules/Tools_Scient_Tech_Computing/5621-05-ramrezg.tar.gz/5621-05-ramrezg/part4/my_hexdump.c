#include <stdio.h>


//function to print usage, in case of miscall to the program
void print_usage(){
  printf("Usage: ./my_hexdump filename\n");
}



//main code
int main(int argc, char **argv){
  //grep_case = 0 [basic], 1 [line nrs], 2 [invert grep], 3 [turn on colour highlightning]
  int i=0, j;

  if(argc > 2){
    print_usage();
    return 0;
  }
  
  //buffers to store input data
  char line[1000];
  char buff_char = '0';
  
  //counter i loops over each character in input stdin
  i = 0, j = 0;
  while(buff_char != EOF){
  
    if(j%16 == 0){
      printf("%.8x  ", j);
      //printf("<damn! %d>", j);
    }
  
    if(i == 8){
      printf(" ");
    }
    
    //getting char from stdin
    buff_char = getc(stdin);
    if(buff_char == '\0' || buff_char == '\a' || buff_char == '\b'
		|| buff_char == '\f' || buff_char == '\n' || buff_char == '\r'
		|| buff_char == '\t' || buff_char == '\v'){
      printf("%.2x ", '.' & 0xff);
      line[i] = '.';
    }
    else{
      printf("%.2x ", buff_char & 0xff);
      line[i] = buff_char;
    }
    
    //incrementing chars counter
    i++;

    //if end of line
    if(i == 16){
    
      line[i] = '\0';

      //reset counter and clean line[]
      i = 0;
      printf(" |%s|\n", line);
    }
    j++;
  }
  //if file finished, then print '.' instead of '\0'
  printf("%.2x ", '.' & 0xff);
  
  //closing last string to print with '\0' character
  line[i-1] = '\0';
  
  //padding to print associated text to last str portion
  if(i<8){
    printf(" ");
  }
  for(;i < 15; i++){
    printf("   ");
  }
  
  printf(" |%s|\n", line);
  printf("%.8x", j+1);

  return 0;
}
