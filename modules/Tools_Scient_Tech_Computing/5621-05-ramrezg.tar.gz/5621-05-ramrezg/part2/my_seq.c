#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>



//function to print usage, in case of miscall to the program
void print_usage(){
  printf("Usage: ./round [-W] [FIRST] [INCREMENT] LAST\n");
}



//main code
int main(int argc, char *argv[]){

  int option = 0, padding = 0;
  int i, j = 0, k;
  int last = 0, increment = 0, first;
  int values[3] = {-1, -1, -1};

  if(argc>5 || argc == 1){
    print_usage();
    return 0;
  }

  while ((option = getopt(argc, argv, "W")) != -1) {
    switch (option) {
      case 'W' :
        padding = 1;
        //getting position of '-W'
        for(i=0; i<argc; i++){
          if(strcmp(argv[i], "-W") == 0){
            j = i;
          }
        }
        break;
      default:
        print_usage();
        return 0;
    }
  }
  
  //in case only -W is set, but no other value is given
  if((argc-1) == j){
    print_usage();
    return 0;
  }

  //TODO: check if first, step, last are all integers >0

  //getting first, step, last values:
  k = 0;
  for(i = 1; i<argc; i++){
    if(i == j){continue;}
    values[k] = atoi(argv[i]);
    k++;
  }

  //setting the correct values for first, step, last

  //in case only last is given:
  if(values[1] == -1){
    values[2] = values[0];
    values[0] = 1;
    values[1] = 1;
  }
  //in case only last and first are given
  else if(values[2] == -1){
    //check if first < last
    if(values[0] > values[1]){
      print_usage();
      return 0;
    }
    values[2] = values[1];
    values[1] = 1;
  }
  else{
    //check if last > first
    if(values[0] > values[2]){
      print_usage();
      return 0;
    }
  }

  //printing output
  //TODO: implement padding here if set from user execution
  for(i=values[0]; i<=values[2]; i+=values[1]){
    printf("%d\n", i);
  }

  return 0;
}
