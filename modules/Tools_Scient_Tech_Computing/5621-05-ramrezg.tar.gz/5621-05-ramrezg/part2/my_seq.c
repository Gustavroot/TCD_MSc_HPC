#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>



//function to print usage, in case of miscall to the program
void print_usage(){
  printf("Usage: ./my_seq [-w] [FIRST] [INCREMENT] LAST\n");
}



//main code
int main(int argc, char *argv[]){

  int option = 0, padding = 0;
  int i, j = 0, k;
  //buffers for inserted values:
  int values[3] = {-1, -1, -1};
  double buff;

  if(argc>5 || argc == 1){
    print_usage();
    return 0;
  }

  while ((option = getopt(argc, argv, "w")) != -1) {
    switch (option) {
      case 'w' :
        padding = 1;
        //getting position of '-w'
        for(i=0; i<argc; i++){
          if(strcmp(argv[i], "-w") == 0){
            j = i;
          }
        }
        break;
      default:
        print_usage();
        return 0;
    }
  }
  
  //restrict '-w' to be located at position 1 in argv
  if(j !=0 && j != 1){
    print_usage();
    return 0;
  }
  
  //in case only -w is set, but no other value is given
  if(argc == 2 && (argc-1) == j){
    print_usage();
    return 0;
  }

  //getting first, step, last values:
  //(obtained in a general way, in case '-w' wants to be located
  //at any position within argv)
  k = 0;
  for(i = 1; i<argc; i++){
    if(i == j){continue;}
    //if value is not INT or it's negative, then exit
    buff = strtod(argv[i], NULL);
    if(buff != (double)((int)buff) || buff < 0){
      print_usage();
      return 0;
    }
    values[k] = (int)buff;
    k++;
  }

  //setting the correct values for first, step, last
  //in case only last is given:
  if(values[1] == -1){
    values[2] = values[0];
    values[0] = 1;
    values[1] = 1;
  }
  //in case only last and first are given
  else if(values[2] == -1){
    //check if first < last
    if(values[0] > values[1]){
      print_usage();
      return 0;
    }
    values[2] = values[1];
    values[1] = 1;
  }
  else{
    //check if last > first
    if(values[0] > values[2]){
      print_usage();
      return 0;
    }
  }

  //printing output
  //padding here if set from user execution
  k = 1;
  if(padding == 1){
    //padding
    buff = (double)values[2];
    while(buff>=1){
      buff /= 10.0;
      k++;
    }
    k--;
  }
  
  //printing is the same regardless of padding, as
  //k contains information about padding
  for(i=values[0]; i<=values[2]; i+=values[1]){
    printf("%.*d\n", k, i);
  }

  return 0;
}
