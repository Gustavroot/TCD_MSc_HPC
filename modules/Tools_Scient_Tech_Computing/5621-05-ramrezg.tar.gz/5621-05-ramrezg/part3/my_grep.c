#include <stdio.h>
#include <getopt.h>
#include <string.h>



//function to print usage, in case of miscall to the program
void print_usage(){
  printf("Usage: ./my_grep [-W] [FIRST] [INCREMENT] LAST [filename]\n");
}


//main code
int main(int argc, char **argv){
  //grep_case = 0 [basic], 1 [line nrs], 2 [invert grep], 3 [turn on colour highlightning]
  int i,j, grep_case = 0, option = 0;
  char *buff_ptr, *k;
  //input data
  FILE *inp_file;
  
  if(argc == 1){
    print_usage();
    return 0;
  }
  
  //'inp_file' is input data: stdin or from file
  inp_file = fopen(argv[argc-1], "r");
  if(inp_file == NULL){
    inp_file = stdin;
  }
  else{
    argc -= 1;
  }
  
  //in case stdin comes NULL
  if(inp_file == NULL){
    print_usage();
    return 0;
  }
  
  //besides data input, max nr of data inputs is 3
  if(argc > 3){
    print_usage();
    return 0;
  }
  
  char keyword[1000];
  
  //getting input by flag
  while ((option = getopt(argc, argv, "n:v:c:")) != -1) {
    switch (option) {
      case 'n' : 
        strcpy(keyword, optarg);
        i=1;
        grep_case = 1;
        break;
      case 'v' : 
        strcpy(keyword, optarg);
        i = 1;
        grep_case = 2;
        break;
      case 'c' : 
        strcpy(keyword, optarg);
        i = 1;
        grep_case = 3;
        break;
      default:
        print_usage();
        return 0;
      
    }
  }

  //in case no flag passed
  if(grep_case == 0){
    strcpy(keyword, argv[1]);
  }

  //buffers to store input data
  char line[1000];
  char *line_ptr;
  char buff_char = '0';
  
  //counter i loops over each character in input stdin
  i = 0, j = 1;
  while(buff_char != EOF){
  
    //getting char from stdin
    buff_char = getc(inp_file);
    line[i] = buff_char;
    i++;

    //if end of line
    if(buff_char == '\n'){
    
      line[i] = '\0';
    
      //check if the input string is within line
      buff_ptr = strstr(line, keyword);
      if(buff_ptr != NULL){
        //case 0
        if(grep_case == 0){
          printf("%s", line);
        }
        //case 1 = -n
        else if(grep_case == 1){
          printf("%d:%s", j, line);
        }
        //case 3
        else if(grep_case == 3){

          k = line;
          //while loop is necessary here to colour all
          //appearances of *keyword
          while(buff_ptr != NULL){
            for(; k != buff_ptr; k++){
              printf("%c", k[0]);
            }
            printf("\033[22;31m%s\033[0m", keyword);
            
            k += strlen(keyword);
            buff_ptr = strstr(k, keyword);
          }
          printf("%s", k);
        }
      }
      //in case of non-matching lines
      else{
        //case 2 = -v
        if(grep_case == 2){
          printf("%s", line);
        }
      }
      
      //reset counter and clean line[]
      i = 0;
      //increase line counter
      j++;
    }
  }

  return 0;
}
