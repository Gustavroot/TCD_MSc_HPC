#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//INITIAL NOTE:
//I know my implementation of the High/Low Method is a little bit different
//to the explanation in the description of the assignment, but in esscence
//it's the same, and the order of the execution time is indeed the same
//(they differ by a factor of 2)

int main(int argc, char *argv[]){
  printf("\nProgram to calculate the square root using the High/Low method.\n\n");

  //Buffers
  int i, j;
  double input_data, decimal_buffer=0, solution=0;

  if(argc==1 || argc>2){
    printf("The number of parameters must be 1.\n");
    return 0;
  }

  //Checking if inserted data is appropriate
  input_data = atof(argv[1]);
  if(input_data==0){
    printf("Wrong input data.\n\n");
    return 0;
  }

  //After checking input params, the core of the program
  //is implemented

  //implementing the High/Low method (accurate to 4 [0.0001] decimal places):
  //..first, locate the integers around the solution
  i=0;
  while(i*i<input_data){
    i++;
  }

  //and now, we know the solution is between i-1 and i
  solution += (double)(i-1);

  //then, the decimal places (up to 6)
  for(i=1; i<7; i++){
    for(j=1; j<10; j++){

      decimal_buffer = 1.0;
      decimal_buffer /= pow(10.0, i);
      decimal_buffer *= (double)j;
      if(pow(solution+decimal_buffer, 2)>input_data){
        decimal_buffer = 1.0;
        decimal_buffer /= pow(10.0, i);
        decimal_buffer *= (double)(j-1);
        solution += decimal_buffer;
        break;
      }
    }
    if(j==10){
      //if completed the loop and didn't break, means it's a 9
      solution += decimal_buffer;
    }
  }

  printf("Solution: %.6f.\n", solution);

  return 0;
}
