#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>


//Function to check if number is square
int is_square(int test_nr){
  int buff_nr;

  //int part of sqrt
  buff_nr = (int)sqrt(test_nr);

  if(buff_nr*buff_nr==test_nr){
    return 1;
  }
  else{return 0;}
}


//Function to check if triangular number
//  N is the nth triangle number if it equals to the sum
//  1+2+...+n for some n (i.e. if n exists)
//  Using Gauss' trick for summing from 1 to n, this can
//  be easily solved
int is_triangular(int test_nr){
  int n;
  double d_n;

  //following formula comes from inverting Gauss' trick and
  //  taking the '+' sign
  d_n = 0.5*(-1+sqrt(1+8*test_nr));
  n = (int)d_n;
  if((d_n-n)==0){
    return 1;
  }
  else{return 0;}
}


//Function to check if string is int
int check_if_int(char str_buff[]){
  for(int i=0; i<strlen(str_buff); i++){
    if(!isdigit(str_buff[i])){return 0;}
  }
  return 1;
}


int main(int argc, char *argv[]){

  printf("\nProgram to display if nr is triangular and/or square.\n\n");

  //Buffers (bool and counter)
  int i, j, k, input_int;

  if(argc==1 || argc>2){
    printf("The number of parameters must be 1.\n");
    return 0;
  }

  //Checking if inserted param is integer
  j=0;
  for(i=1; i<argc; i++){
    if(check_if_int(argv[i]) == 0){j++;}
  }
  if(j>0){
    printf("The required param must be an integer.\n\n");
    return 0;
  }

  //After checking input params, the core of the program
  //is implemented

  //extracting the input int
  input_int = atoi(argv[1]);

  for(i=1; i<=input_int; i++){
    j = is_triangular(i);
    k = is_square(i);
    if(j==1 && k==1){
      printf("%d is both square and triangular.\n", i);
    }
    else if(j==1){
      printf("%d is only triangular.\n", i);
    }
    else if(k==1){
      printf("%d is only square.\n", i);
    }
    else{
      printf("%d is not square or triangular.\n", i);
    }
  }

  return 0;
}
